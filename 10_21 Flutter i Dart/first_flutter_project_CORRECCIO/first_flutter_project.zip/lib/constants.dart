
const logoUrl = "https://static.vecteezy.com/system/resources/previews/008/467/137/original/url-letter-logo-creative-design-with-graphic-vector.jpg";