

class Season{

  int id;
  int? number;
  int? episodeOrder;
  String? name;
  String? image;
  String? summary;

  Season({required this.id, this.number, this.episodeOrder,
      this.name, this.image,this.summary});

  factory Season.fromJson(Map<String,dynamic> json){

    return Season(
      id: json["id"],
      number: json["number"],
      episodeOrder: json["episodeOrder"],
      name: json["name"],
      image: json["image"] != null ? json["image"]["original"] : null,
      summary: json["summary"]

    );

  }


}