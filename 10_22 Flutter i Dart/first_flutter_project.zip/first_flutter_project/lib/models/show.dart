
class Show{
  int id;
  String name;
  List<String>? genres;
  String? image;
  String? summary;

  Show({required this.id, required this.name, this.genres,this.image,this.summary });

  factory Show.fromJson(Map<String,dynamic> json){
    return Show(
      id: json["id"],
      name: json["name"],
      genres: List.from(json["genres"]),
      //LA IMAGEN QUE ME INTERESA LA TENDRE EN json["image"]["original"]
      image: json["image"] != null ? json["image"]["original"] : null,
      summary: json["summary"]


    );
  }

}