


import 'package:first_flutter_project/components/episodes_list_widget.dart';
import 'package:first_flutter_project/models/show.dart';
import 'package:first_flutter_project/pages/seasons_list_page.dart';
import 'package:first_flutter_project/repositories/show_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';

class ShowDetailPage extends StatefulWidget {

  int showId;

  ShowDetailPage({super.key,required this.showId});

  @override
  State<ShowDetailPage> createState() => _ShowDetailPageState();
}

class _ShowDetailPageState extends State<ShowDetailPage> {

  Show? _show;

  @override
  void initState(){
    super.initState();



    _loadData();

    //AQUI CARGAREMOS LOS DATOS DE NUESTRO SHOW
  }

  Future<void> _loadData() async {
    _show = await ShowRepository().getShowDetail(widget.showId.toString());
    //await Future.delayed(Duration(seconds: 2));

    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_show != null ? "${_show?.name}" : "loading..."),
      ),
      body: Column(
        children: [
          Expanded(
            flex:2,
            child: Container(
              color: Colors.white,
              child:_show != null ? Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex:1,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        child: Column(
                          children: [
                            _show?.image != null 
                                ? Image.network(_show?.image ?? "")
                                : Image.asset("assets/movie.png"),
                            SizedBox(height: 10,),
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.blue,
                                borderRadius: BorderRadius.circular(15)
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal:8,vertical: 5),
                                child: Text("9.1",style: TextStyle(fontSize: 30,color: Colors.white),),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    flex:2,
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: SingleChildScrollView(
                        child: Container(
                          child: HtmlWidget("${_show?.summary ?? "Not available"}"),
                        ),
                      ),
                    ),
                  )
                ],
              ) : Center(child: CircularProgressIndicator())
            ),
          ),
          Container(
            height: 40,
            alignment: Alignment.centerLeft,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal:15.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Show episodes",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),

                  TextButton(
                    onPressed: (){
                      print("Navegando a listado de seasons");

                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (context)=>SeasonsListPage(showId: _show?.id ?? 0,))
                      );
                    },
                    child: Text("Seasons"),

                  )
                ],
              ),
            ),
          ),
          Expanded(
            flex:3,
            child: Container(
              color: Colors.white,
              child: EpisodesListWidget(showId: widget.showId),
            ),
          )
        ],
      ) 
      
    );
  }
}
