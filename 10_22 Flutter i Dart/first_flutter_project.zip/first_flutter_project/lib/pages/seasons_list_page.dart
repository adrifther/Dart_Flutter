

import 'package:first_flutter_project/components/list_seasons_widget.dart';
import 'package:first_flutter_project/models/season.dart';
import 'package:first_flutter_project/repositories/show_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';

class SeasonsListPage extends StatefulWidget {

  int showId;

  SeasonsListPage({super.key,required this.showId});

  @override
  State<SeasonsListPage> createState() => _SeasonsListPageState();
}

class _SeasonsListPageState extends State<SeasonsListPage> {

  List<Season>? _seasons;

  bool _gridMode = false;

  @override
  void initState(){
    super.initState();

    _loadData();
  }

  Future<void> _loadData() async {
    _seasons = await ShowRepository().getSeasons(widget.showId.toString());

    setState(() {

    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(

        title: Text("Seasons"),
        actions: [
          IconButton(
            color: _gridMode ? Colors.black : Colors.red,
            onPressed: (){
                setState(() {
                  _gridMode = false;
                });
            },
            icon: Icon(Icons.list),
          ),
          IconButton(
            color: _gridMode ? Colors.red : Colors.black,
            onPressed: (){
                setState(() {
                  _gridMode = true;
                });
            },
            icon: Icon(Icons.grid_3x3_sharp),
          )
        ],
      ),
      body: Center(
        child: Column(
          children: [
            Expanded(
                child: _gridMode == false ? ListSeasonsWidget(seasons: _seasons) : GridView.builder(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: 0.5
                  ),
                  itemCount: _seasons?.length ?? 0,
                  itemBuilder: (context,index){
                    return Container(
                      //color: Colors.yellow,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.network(_seasons?[index].image ?? ""),
                          SizedBox(height: 10,),
                          Text("Season ${_seasons?[index].number}")
                        ],
                      ));

                  }
                )
            )
          ],
        ),
      ),
    );
  }
}

