

import 'package:first_flutter_project/models/episode.dart';
import 'package:first_flutter_project/repositories/show_repository.dart';
import 'package:flutter/material.dart';

class EpisodesListWidget extends StatefulWidget {

  int showId;

  EpisodesListWidget({super.key,required this.showId});

  @override
  State<EpisodesListWidget> createState() => _EpisodesListWidgetState();
}

class _EpisodesListWidgetState extends State<EpisodesListWidget> {

  List<Episode>? _episodesList;


  @override
  void initState(){
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    _episodesList = await ShowRepository().getEpisodes(widget.showId.toString());
    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return _episodesList != null ? ListView.separated(
        separatorBuilder: (context,index){
          return Divider();
        },
        itemCount: _episodesList?.length ?? 0 ,
        itemBuilder: (context,index){
          return ListTile(
            textColor: Colors.black,

            title: Text(_episodesList?[index].name ?? ""),
          );
        }) : Center(child: CircularProgressIndicator());
  }
}
