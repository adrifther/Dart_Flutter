
import 'package:first_flutter_project/models/season.dart';
import 'package:flutter/material.dart';
import 'package:flutter_widget_from_html/flutter_widget_from_html.dart';

class ListSeasonsWidget extends StatefulWidget {
  List<Season>? seasons;


  ListSeasonsWidget({
    super.key,
    this.seasons
  });

  @override
  State<ListSeasonsWidget> createState() => _ListSeasonsWidgetState();
}

class _ListSeasonsWidgetState extends State<ListSeasonsWidget> {



  List<bool> _expandeds = List.generate(100, (index)=>false);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();





  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,

      child: SingleChildScrollView(
        child: ExpansionPanelList(
          expansionCallback: (int index, bool isExpanded){
            print("INDEX $index is expanded :$isExpanded");
            setState(() {
              _expandeds[index] = !_expandeds[index];
            });


          },
          children: widget.seasons?.map(
              (element)=>buildExpansionPanel(element)
          ).toList() ?? [],
        ),
      ),
    );
  }

  ExpansionPanel buildExpansionPanel(Season season) {

    var index = widget.seasons?.indexOf(season) ?? 0;

    return ExpansionPanel(
                isExpanded: _expandeds[index],
                canTapOnHeader: true,
                headerBuilder: (context,isExpanded){
                  return ListTile(
                    title: Text("Season ${season.number}"),
                  );
                },
                body: ListTile(
                  title: HtmlWidget("${season.summary}"),
                  subtitle: Text("Subtitulo expandido"),
                )
              );
  }
}