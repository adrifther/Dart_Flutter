package com.cifo.project.first_flutter_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
