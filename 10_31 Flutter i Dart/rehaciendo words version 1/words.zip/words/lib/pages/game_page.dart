

import 'package:flutter/material.dart';

import '../components/result_widget.dart';

class GamePage extends StatefulWidget {
  GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Column(
          children: [
            Expanded(
                flex: 2,
                child: Container(
                  alignment: Alignment.center,
                  // width: double.infinity,
                  // color: Colors.red,
                  child: ResultWidget(result: "Pepe"),
                )),
            Expanded(
                flex: 4,
                child: Container(
                  alignment: Alignment.center,
                  color: Colors.blue,
                  child: Text("grid letras"),
                )),
            Expanded(
                flex: 1,
                child: InkWell(
                  onTap: (){
                    print("hola");
                  },
                  child: Container(
                    alignment: Alignment.center,
                    color: Colors.cyanAccent,
                    child: Text("VALIDAR"),
                  ),
                ))
          ],
        ),
      ),
    );
  }
}


