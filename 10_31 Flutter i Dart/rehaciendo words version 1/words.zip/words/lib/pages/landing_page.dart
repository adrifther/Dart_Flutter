

import 'package:flutter/material.dart';
import 'package:words/pages/game_page.dart';

class LandingPage extends StatelessWidget {
  LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
          body: Stack(
            alignment: Alignment.center,
            children: [ 
              Column(
                children: [
                  Expanded(
                    child: Container(
                      decoration: BoxDecoration(
                        image: DecorationImage(image: AssetImage("assets/background_landing.jpg"), fit: BoxFit.cover)
                      ),
                    ),
                  )
                ],
              ),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Expanded(
                    flex: 2,
                    child: Container(
                      alignment: Alignment.bottomCenter,
                      width: double.infinity,
                      color: Colors.transparent,
                      child: InkWell(
                        onTap: (){
                          Navigator.of(context).push(
                            MaterialPageRoute(builder: (context)=>GamePage())
                          );
                        },
                        child: Container(
                          padding: EdgeInsets.all(20.0),
                          decoration: BoxDecoration(
                            border: Border.all(width: 2.0),
                            borderRadius: BorderRadius.circular(30)
                          ),
                          child: Text("START", style: TextStyle(
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: Colors.white
                          ),),
                        ),
                      )),
                    ),
                  SizedBox(height: 30,),
                  Expanded(
                    flex: 2,
                    child: Container(
                      alignment: Alignment.topCenter,
                      width: double.infinity,
                      color: Colors.transparent,
                      child: Text("WORDS", style: TextStyle(
                        fontSize: 50,
                        fontWeight: FontWeight.bold
                      ),),
                    ),
                  ),

                ],
              ),
              Positioned(
                bottom: 10,
                right: 10,
                child: Text("v.0.0.1(beta)", style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.cyanAccent.withOpacity(0.5)
                ),),
              )
            ]
          )
        ));
  }
}








