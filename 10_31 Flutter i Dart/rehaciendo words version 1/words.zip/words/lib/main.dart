

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:words/pages/game_page.dart';
import 'package:words/pages/landing_page.dart';

void main(){
  runApp(WordsApp());
}



class WordsApp extends StatefulWidget {
  const WordsApp({super.key});

  @override
  State<WordsApp> createState() => _WordsAppState();
}

class _WordsAppState extends State<WordsApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: LandingPage());
  }
}
