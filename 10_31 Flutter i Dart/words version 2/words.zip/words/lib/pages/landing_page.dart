

import 'package:flutter/material.dart';
import 'package:words/pages/game_page.dart';

class LandingPage extends StatelessWidget {
  const LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(  //para poner imagen, en background de container
      backgroundColor: Colors.white,// sólo poner color en uno de los dos
      body:
      Stack(// columna es la base del stack, para poner algo encima hay que ponerlo en el código debajo de llamar a la columna
        alignment: Alignment.center,
        children: [
          
          Column(
            children: [
          
              Expanded(
                child: Container(
             //   color: Colors.grey,     // sólo poner color en uno de los dos
          
                  decoration: BoxDecoration(
          
                      image: DecorationImage(
                      image: AssetImage("assets/background_landing.jpg"),
                      fit: BoxFit.cover,
                    )
                  ),
                ),
              ),
            ],
          ),
          
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                child:

                Text(
                  "WORDS",
                  style: TextStyle(
                    fontSize: 50,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),

              ),

              SizedBox(
                  height: 20
              ),

              InkWell(
                onTap: (){

                  Navigator.of(context).push(
                      MaterialPageRoute(builder: (context)=> GamePage()));

                },
                child: Container(
                  padding: EdgeInsets.all(5.00),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      width: 2,
                      color: Colors.white,
                    )
                  ),
                  child: Text(
                    "START",
                    style: TextStyle(
                      fontWeight: FontWeight.normal,
                      color: Colors.white,
                      fontSize: 50.00
                    ),
                  ),
                ),
              ),
            ],
          ),

          Positioned( // Positioned sólo funciona en stack. El tamaño del stack es el tamaño mas grande que contiene.
            bottom: 10,
            right: 10,

            child: Text(
              "V. 0.1",
              style: TextStyle(fontSize: 20),
            ),
          )
          
        ],
      ),
    );
  }
}

/* Theme(
        data: ThemeData(
          scaffoldBackgroundColor: Colors.white,
          textTheme: TextTheme(),
        ),
        child: ,
      ), */