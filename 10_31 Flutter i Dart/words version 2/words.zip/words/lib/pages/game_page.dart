

import 'package:flutter/material.dart';
import 'package:words/components/letters_widget.dart';
import 'package:words/components/result_widget.dart';

class GamePage extends StatefulWidget {
  GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {

  var _result = "";

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body:Column(
          children: [
            Expanded(
              flex: 2,
                child: Container(
                  alignment: Alignment.center,
                  color: Colors.white,
                  child: ResultsWidget(result: _result),
                )
            ),

            Expanded(
              flex: 4,
                child: Container(
                  alignment: Alignment.center,
                  color: Colors.green,
                  child: LettersWidget(
                    onClearPressed: (){
                      _result = "";
                      setState(() {

                      });
                    },
                    onLetterPressed: (value){
                      _result += value;
                      setState(() {

                      });
                      print("me han clicado la letra $value");
                    },
                    onDeleteLastCharacter: (){
                      if(_result.isNotEmpty){
                        _result =  _result.substring(0,_result.length-1);
                      }
                      setState(() {

                      });
                }
                  ),
                )
            ),

            Expanded(
              flex: 1,
                child: Container(
                  alignment: Alignment.center,
                  color: Colors.cyan,
                  child: InkWell(
                    onTap: (){

                    },
                    child: Text("VALIDAR"),
                  ),
                ))
          ],
        )
      ),
    );
  }
}


