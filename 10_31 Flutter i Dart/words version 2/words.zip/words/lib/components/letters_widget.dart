

import 'dart:math';

import 'package:flutter/material.dart';

class LettersWidget extends StatelessWidget {

  Function onLetterPressed;

  Function onClearPressed;

  Function onDeleteLastCharacter;

  List<String> letters = ["A","B","C","D","E","F","G","H","I","J"]; //,"K","L","M","N","O","P","Q","R","S","T","U"];

  LettersWidget({super.key, required this.onLetterPressed, required this.onClearPressed, required this.onDeleteLastCharacter});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(
                  onPressed: (){
                    onClearPressed(); //hay que poner widget.onClearPressed() si estamos en Stateful Widget.
                  },
                  child: Text("Clear"),
              ),
              ElevatedButton(
                  onPressed: (){
                onDeleteLastCharacter();
              },
                  child: Icon(Icons.backspace)
              ),



            ],
          ),
          SizedBox(height: 100,),
          GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount:5,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
            ),
            shrinkWrap: true,
            itemCount: letters.length,
            itemBuilder: (context,index){
              return InkWell(
                  onTap: (){
                    onLetterPressed(letters[index]);
                  },
                  child: Container(
                    alignment: Alignment.center,
                    color: Colors.white,
                    child: Text(
                        "${letters[index]}",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                        color:  Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                      ),
                    ),
                  )
              );
            },
          ),
        ],
      ),
    );
  }
}
