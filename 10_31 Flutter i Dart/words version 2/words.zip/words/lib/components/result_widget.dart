import 'package:flutter/material.dart';

class ResultsWidget extends StatelessWidget {

  String result;  //no es privada porque tiene que ir a otro widget (osea otra clase)



  ResultsWidget({
    super.key,
    required this.result,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 25),
        alignment: Alignment.centerRight,
        width: MediaQuery.of(context).size.width*0.7,
        height: 70,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              width: 2.0,
              style: BorderStyle.solid,
            )
        ),
        child: Text(
          "${result}",
          style: TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            letterSpacing: 5,

          ),
        )
    );
  }
}