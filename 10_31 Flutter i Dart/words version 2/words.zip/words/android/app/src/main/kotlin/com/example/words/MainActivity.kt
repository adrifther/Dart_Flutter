package com.example.words

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
