package com.example.social_cifo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
