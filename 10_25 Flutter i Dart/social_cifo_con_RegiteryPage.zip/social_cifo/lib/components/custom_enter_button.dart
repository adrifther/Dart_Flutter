
import 'package:flutter/material.dart';
import 'package:social_cifo/constants.dart';

class CustomEnterButton extends StatelessWidget {

  Function onTap;
  String buttonText;

  CustomEnterButton({
    super.key,
    required this.onTap,
    this.buttonText = "Sign in"
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: ()=>onTap(),
      child: Container(
        decoration: BoxDecoration(
            color: kPrimaryColor,
            borderRadius: BorderRadius.circular(10)
        ),
        alignment: Alignment.center,
        width: double.infinity,
        height: 80,
        child: Text(buttonText, style: TextStyle(
            fontSize: 16,
            color: Colors.white.withOpacity(0.8)),),
      ),
    );
  }
}