import 'package:flutter/material.dart';
import 'package:social_cifo/components/back_botton_widget.dart';
import 'package:social_cifo/constants.dart';
import 'package:social_cifo/models/users_data.dart';
import 'package:social_cifo/pages/posts_page.dart';
import 'package:social_cifo/repositories/user_repository.dart';

import '../models/user.dart';

class UserListPage extends StatefulWidget {
  const UserListPage({super.key});

  @override
  State<UserListPage> createState() => _UserListPageState();
}

class _UserListPageState extends State<UserListPage> {

  UsersData? _userData;

  int _page = 1;
  
  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _loadData();

  }
  
  bool shouldLoadMore(){
    
    var limit = _userData?.limit ?? 0;
    var total = _userData?.total ?? 0;
    
    return (total / limit) > _page;
    
  }

  Future<void> _loadData({int page = 1}) async {

    if(_userData == null){
      _userData = await UserRepository().getUserList(page: page);
    }else{
      var tempUserData = await UserRepository().getUserList(page:page);
      _userData?.users?.addAll(tempUserData.users ?? []);
    }


    setState(() {
      
    });
    
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 110,
          leadingWidth: 110,
        leading: Padding(
          padding: const EdgeInsets.all(25.0),
          child: BackBottonWidget(),
        ),
        title: Text("Followers(4k)"),
      ),
      body: _userData != null ? Container(
        height: double.infinity,
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                  itemCount: (_userData?.users?.length ?? 0) + (shouldLoadMore() ? 1 : 0),
                  itemBuilder: (context,index){

                    if(index >= (_userData?.users?.length ?? 0) ){
                      return ElevatedButton(
                          onPressed: (){
                            _page++;
                            _loadData(page: _page);
                          }, child: Text("Load more"));
                    }

                    return ListTile(
                      onTap: (){
                        Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (context)=>PostsPage(userId: _userData?.users?[index].id ?? "")
                          )
                        );
                      },
                      leading: Container(
                        width: 60,
                        height: 60,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50),
                          child: Image.network(
                                "${kImageBaseUrl}/${_userData?.users?[index].image}",
                                fit: BoxFit.cover,
                            ),
                        ),
                      ),
                      title: Text("${_userData?.users?[index].name}" ),
                      subtitle: Text("${_userData?.users?[index].email}" ),
                      trailing: Container(
                        height: 30,
                        width: 100,
                        decoration: BoxDecoration(
                          color: kPrimaryColor,
                          borderRadius: BorderRadius.circular(50),
              
                        ),
                        alignment: Alignment.center,
                        child: Text("Follow",style: TextStyle(fontSize: 14,color: Colors.white),),
                      ),
                    );
                  }
              ),
            ),

          ],
        ),

      ) : Center(child: CircularProgressIndicator(),),
      
    );
  }
}
