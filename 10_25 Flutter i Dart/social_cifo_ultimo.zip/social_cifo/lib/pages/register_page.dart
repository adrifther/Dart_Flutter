
import 'package:flutter/material.dart';
import 'package:social_cifo/components/back_botton_widget.dart';
import 'package:social_cifo/components/custom_enter_button.dart';
import 'package:social_cifo/helpers/form_helpers.dart';
import 'package:social_cifo/repositories/user_repository.dart';

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {

  var _nameController = TextEditingController();
  var _emailController = TextEditingController();
  var _nickController = TextEditingController();
  var _passwordController = TextEditingController();
  var _repeatPasswordController = TextEditingController();

  var _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 110,
          leadingWidth: 110,
          leading: Padding(
            padding: const EdgeInsets.all(25.0),
            child: BackBottonWidget(),
          )
      ),
      body: Container(
        width: double.infinity,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text("Register now",style: Theme.of(context).textTheme.headlineLarge,),
            Text("Create new account",style: Theme.of(context).textTheme.titleSmall,),
            SizedBox(height:40),
            Padding(
              padding: const EdgeInsets.all(20.0),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    TextFormField(
                      controller:_nameController,
                      decoration: InputDecoration(
                          label: Text("*Name"),
                          hintText: "Enter your name"
                      ),
                      validator: (value){
                        if(FormHelpers.isEmpty(value)){
                          return "Name can not be empty";
                        }
                        return null;
                      },
                    ),
                    SizedBox(height:10),
                    TextFormField(
                      controller: _emailController,
                      decoration: InputDecoration(
                          hintText: "Enter your email"
                      ),
                      validator: (String? value){
                        if(FormHelpers.isEmpty(value)){
                          return "Email can not be empty";
                        }

                        if(!FormHelpers.isValidEmail(value)){
                          return "Email is not valid";
                        }

                        return null;

                      },
                    ),
                    SizedBox(height:10),
                    TextFormField(
                      controller: _nickController,
                      decoration: InputDecoration(
                          hintText: "Enter your nickname"
                      ),
                      validator: (value){
                        if(FormHelpers.isEmpty(value)){
                          return "Nickname can not be empty";
                        }
                        return null;
                      },
                    ),
                    SizedBox(height:10),
                    TextFormField(
                      controller: _passwordController,
                      decoration: InputDecoration(
                          hintText: "Enter your password"
                      ),
                      validator: (value){
                        if(!FormHelpers.isValidPass(value)){
                          return "Not a valid password";
                        }

                        return null;
                      },
                    ),
                    SizedBox(height:10),
                    TextFormField(
                      controller: _repeatPasswordController,
                      decoration: InputDecoration(
                          hintText: "Repeat your password"
                      ),
                      validator: (value){
                        if(value != _passwordController.text){
                          return "Passwords should match";
                        }

                        return null;
                      },
                    ),
                  ],
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(20.0),
              child: CustomEnterButton(
                  buttonText: "Sign up",
                  onTap: () async {
                    if(_formKey.currentState?.validate() ?? false){

                      try {
                        await UserRepository().register(
                            name: _nameController.text,
                            email: _emailController.text,
                            nick: _nickController.text,
                            password: _passwordController.text);

                        //SI LLEGAMOS AQUI, EL USUARIO SE HA REGISTRADO CORRECTAMENTE
                        showDialog(
                            barrierDismissible: false,
                            context: context,
                            builder: (context){
                              return AlertDialog(

                                title: Text("User successfully registered"),
                                content: Text("Please, enter your credentials at login page"),
                                actions: [
                                  ElevatedButton(onPressed: (){
                                      Navigator.of(context).pop();
                                      Navigator.of(context).pop();
                                  }, child: Text("OK!"))
                                ],
                              );
                            });


                      }catch(e){
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("${e.toString()}"))
                        );
                      }
                    }
                  }),
            )

          ],
        ),
      )
    );
  }
}
