

class Publication{

  String id;
  String? text;
  DateTime? createdAt;

  Publication({ required this.id, this.text, this.createdAt});

  factory Publication.fromJson(Map<String,dynamic> json){

    return Publication(
      id: json["_id"],
      text: json["text"],
      createdAt: DateTime.tryParse(json["created_at"])
    );


  }


}