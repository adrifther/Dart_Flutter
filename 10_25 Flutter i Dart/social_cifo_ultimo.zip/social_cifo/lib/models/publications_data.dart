

import 'package:social_cifo/models/publication.dart';

class PublicationsData{

  int page;
  int total;
  int limit;

  List<Publication>? publications;

  PublicationsData({
    required this.page,
    required this.total,
    required this.limit,
    required this.publications
  });

  factory PublicationsData.fromJson(Map<String,dynamic> json){

    return PublicationsData(
      page: json["page"],
      total: json["total"],
      limit: json["limit"],
      publications: json["publications"] != null
          ? List.from(json["publications"])
              .map((e)=>Publication.fromJson(e)).toList() : null
    );


  }



}