

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:social_cifo/constants.dart';
import 'package:social_cifo/models/publications_data.dart';
import 'package:http/http.dart' as http;


class PostsRepository {

  Future<PublicationsData> getUsersPosts({required String userId,int page=1}) async {

    var url = "$kBaseUrl/publication/user/$userId?page=$page";

    Uri uri = Uri.parse(url);

    var prefs = await SharedPreferences.getInstance();
    var token = prefs.getString("token") ?? "";

    var response = await http.get(uri,headers: {
      "Authorization":token
    });

    if(response.statusCode >= 200 && response.statusCode < 300){
      //EN ESTE CASO DEVOLVEREMOS EL OBJETO PUBLICATIONSDATA
      var parsedResponse = jsonDecode(response.body);

      return PublicationsData.fromJson(parsedResponse["data"]);
    }else{
      print("RESPONSE BODY ${response.body}");
      throw Exception("There was an error loading posts");
    }


  }




}