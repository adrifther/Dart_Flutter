


import 'package:flutter/material.dart';
import 'package:social_cifo/models/publication.dart';

class PostWidget extends StatelessWidget {

  Publication? publication;

  PostWidget({super.key,required this.publication});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 180,
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black45,width: 2)
      ),
      child: ListTile(
        title: Text(publication?.text ?? "N/A"),
        subtitle: Text("${publication?.createdAt}"),
      ),
    );
  }
}
