

import 'package:social_cifo/models/user.dart';

class UsersData{

  int page;
  int total;
  int limit;

  List<User>? users;

  UsersData({
    required this.page,
    required this.total,
    required this.limit,
    this.users
  });

  factory UsersData.fromJson(Map<String,dynamic> json){

    return UsersData(
      page: json["page"],
      total: json["total"],
      limit: json["limit"],
      users: json["users"] != null
          ? List.from(json["users"]).map((e)=>User.fromJson(e)).toList() : null
    );

  }


}