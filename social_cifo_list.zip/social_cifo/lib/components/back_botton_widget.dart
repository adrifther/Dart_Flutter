


import 'package:flutter/material.dart';
import 'package:social_cifo/constants.dart';

class BackBottonWidget extends StatelessWidget {
  const BackBottonWidget({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: (){
        Navigator.of(context).pop();
      },
      child: Container(
        decoration: BoxDecoration(
            color: kPrimaryColor,
            borderRadius: BorderRadius.circular(10) ),
        child: Icon(Icons.arrow_back, color: Colors.white),
      ),
    );
  }
}