
import 'package:flutter/material.dart';
import 'package:social_cifo/pages/login_page.dart';

class OnboardingPage extends StatelessWidget {
  OnboardingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Container(
          child: ElevatedButton(onPressed: (){
            Navigator.of(context).push(
              MaterialPageRoute(builder: (context)=>LoginPage())
            );
          },
              child: Text("START")),
        ),
      ),
    );
  }
}
