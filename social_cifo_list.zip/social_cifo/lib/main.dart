


import 'package:flutter/material.dart';
import 'package:social_cifo/constants.dart';
import 'package:social_cifo/pages/onboarding_page.dart';

import 'pages/login_page.dart';

void main(){

  runApp(MainApp());

}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // ESTE THEM DATA SE PUEDE METER EN VARIABLE Y TAMBIEN SE USA PARA DARKMODE Y LIGHTMODE
      theme: ThemeData(
        // textButtonTheme: TextButtonThemeData(
        //   style: ButtonStyle(
        //     textStyle: WidgetStatePropertyAll<TextStyle>(
        //       TextStyle(
        //         color: Colors.green
        //       )
        //     )
        //   )
        // ),
        inputDecorationTheme: InputDecorationTheme(
          labelStyle: TextStyle(color: kPrimaryColor),
          hintStyle: TextStyle(color: Colors.black26),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.black12)
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: kPrimaryColor, width: 3),
            borderRadius: BorderRadius.circular(10)
          )
        ),
        textTheme: TextTheme(
          headlineLarge: TextStyle(
            fontSize: 50,
            fontWeight: FontWeight.bold
          ),
          titleSmall: TextStyle(
            fontSize: 16,
            color: Colors.black45
          )
        )
      ),
      home: OnboardingPage()
    );
  }
}
