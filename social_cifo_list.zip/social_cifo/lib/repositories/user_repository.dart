
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:social_cifo/constants.dart';
import 'package:http/http.dart' as http;
import 'package:social_cifo/models/users_data.dart';

import '../models/user.dart';

class UserRepository{

  Future<bool> login(String user, String password) async {
    var url = "$kBaseUrl/user/login";

    Uri uri = Uri.parse(url);

    var response = await http.post(uri, body: {
      "email": user,
      "password": password,
    });

    if(response.statusCode >= 200 && response.statusCode < 300){
      var parsedResponse = jsonDecode(response.body);
      print("TOKEN IS ${parsedResponse["token"]}");

      //Guardamos el token en las shared prederences

      var prefs = await SharedPreferences.getInstance();

      prefs.setString("token",parsedResponse["token"]);

      return true;
    }else{
      throw Exception("Error login user ${response.statusCode}");
    }

  }

  Future<UsersData> getUserList({int page = 1}) async {

    var url = "$kBaseUrl/user/list/$page";

    Uri uri = Uri.parse(url);

    var pref = await SharedPreferences.getInstance();
    var token = pref.getString("token") ?? "";

    var response = await http.get(
      uri,
      headers: { "Authorization": token}
    );

    if(response.statusCode >= 200 && response.statusCode < 300){
      var parsedResponse = jsonDecode(response.body);
      
      var userData = UsersData.fromJson(parsedResponse["data"]);

      return userData;

    } else{
      throw Exception("ERROR AL CARGAR $response");
    }

  }

}