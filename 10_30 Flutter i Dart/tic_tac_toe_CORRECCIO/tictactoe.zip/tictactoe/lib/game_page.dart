import 'dart:math';

import 'package:flutter/material.dart';

class GamePage extends StatefulWidget {
String side;
   GamePage({super.key, required this.side});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {

  List<int> _board = List.generate(9,(index)=>0);

  var playerWin = 0;
  var cpuWin = 0;
  var draw = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff43115B),
      body:

      Padding(
        padding: const EdgeInsets.all(40.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GridView(
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                childAspectRatio: 1,
                crossAxisCount: 3,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
              ),
              children: [
                Container(
                  width: 50,
                  height: 50,
                  color: Color(0xff48D2FE),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Player", style: TextStyle(fontSize: 25),),
                      Text("${playerWin}", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),)
                    ],
                  ),
                ),
                Container(
                  width: 50,
                  height: 50,
                  color: Color(0xffBBDBF9),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Draw", style: TextStyle(fontSize: 25),),
                      Text("${draw}", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),)
                    ],
                  ),
                ),
                Container(
                  width: 50,
                  height: 50,
                  color: Color(0xffE2BE00),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("CPU", style: TextStyle(fontSize: 25),),
                      Text("${cpuWin}", style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),)
                    ],
                  ),
                ),


              ],
            ),
            GridView.builder(
                shrinkWrap: true,
                itemCount: _board.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                ),
                itemBuilder: (context,index) {
                  return InkWell(
                    onTap: (){
                      if (_board[index]== 0){
                        setState(() {
                          _board[index] = 1;
                        });
                        if (checkWin(1)){
                          showAlert("YOU WIN!!!!");
                          setState(() {
                            playerWin++;
                          });
                          // Avisar a l'usuari que ha guanyat
                          return;
                        };
                        if (checkDraw()){
                          showAlert("DRAW");
                          setState(() {
                            draw++;
                          });
                          return;
                        }
                        playCpu();
                        if (checkWin(-1)){
                          showAlert("CPU WIN!!!!");
                          setState(() {
                            cpuWin++;
                          });
                          // Avisar a la cpu que ha guanyat
                          return;
                        };



                      }







                      setState(() {});
                    },
                    child: Container(
                      color: Color(0xff5A1E76),
                      height: 50,
                      width: 50,
                      alignment: Alignment.center,
                      child:
                          _board[index]==0 ?
                          SizedBox() : _board[index]==1
                           ? Image.asset(widget.side=="D"? 'assets/donut.png' : 'assets/pretzel.png')
                            :Image.asset(widget.side=="D"? 'assets/pretzel.png' : 'assets/donut.png'),
                      //Image.asset('assets/donut.png'),
                      //Text("${_board[index]}"),

                    ),
                  );
                }),
          ],
        ),
      )
    );
  }

  bool checkWin (player){
    if   ((_board [0]==player && _board[1]==player &&_board[2]==player)
        ||(_board [3]==player && _board[4]==player &&_board[5]==player)
        ||(_board [6]==player && _board[7]==player &&_board[8]==player)
        ||(_board [0]==player && _board[3]==player &&_board[6]==player)
        ||(_board [1]==player && _board[4]==player &&_board[7]==player)
        ||(_board [2]==player && _board[5]==player &&_board[8]==player)
        ||(_board [0]==player && _board[4]==player &&_board[8]==player)
        ||(_board [2]==player && _board[4]==player &&_board[6]==player)
    ) {
      print("WIN");
      return true;
      }else{
      return false;
      }
  }

  void playCpu (){

    int A = Random().nextInt(9);
    while (_board[A]!=0){
       A = Random().nextInt(9);
    }
    setState(() {
      _board[A] = -1;
    });
    //print(A);
    //print("${_board}");
  }

  bool checkDraw (){
    if (_board.contains(0)){
      return false;
    }else{
      return true;
    }
  }

  void showAlert (String message){
    showDialog(
        context: context,
        builder: (context){
          return AlertDialog(
            content: Text(message),
            actions: [
              TextButton(
                  onPressed:(){
                    _board.fillRange(0,9,0);
                    setState(() {});
                    Navigator.of(context).pop();
                  },
                  child: Text("OK"))
            ],
          );
        }
    );

  }



}
