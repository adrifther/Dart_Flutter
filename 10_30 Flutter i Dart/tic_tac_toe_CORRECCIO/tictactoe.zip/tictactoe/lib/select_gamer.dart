import 'package:flutter/material.dart';
import 'package:tictactoe/game_page.dart';

class SelectGamer extends StatefulWidget {
   SelectGamer({super.key});

  @override
  State<SelectGamer> createState() => _SelectGamerState();
}

class _SelectGamerState extends State<SelectGamer> {
  var seleccion = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff5A1E76),
      body: Column(
        children: [
          Expanded(
            flex: 1,
              child: Container(
                        //color: Colors.blue,
                        alignment: Alignment.center,
                        child: Text("Select your icon",
                          style: TextStyle(fontSize: 40, color: Colors.white),
                        ),
                     )
          ),
          Expanded(
              flex: 3,
              child: Container(
                //color: Colors.red,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap:(){
                        seleccion = "D";
                        setState(() {});
                      },
                      child: Container(
                          color: seleccion == "D" ? Colors.blue
                              : Colors.transparent,
                          width: MediaQuery.of(context).size.width/3,
                          child: Image.asset("assets/donut.png")
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        seleccion = "P";
                        setState(() {});
                      },
                      child: Container(
                          color: seleccion == "P" ? Colors.blue
                              : Colors.transparent,
                          width: MediaQuery.of(context).size.width/3,
                          child: Image.asset("assets/pretzel.png")

                      ),
                    )
                  ],
                ),
              )
          ),
          Expanded(
              flex: 2,
              child: Container(
                alignment: Alignment.center,
                child: InkWell(
                  onTap: (){
                    seleccion != ""? Navigator.of(context).push(
                      MaterialPageRoute(builder: (context)=> GamePage(side: seleccion))
                    ) : null;
                  },
                  child: Container(
                   // alignment: Alignment.center,
                    decoration: BoxDecoration(
                        border: Border.all(color:Colors.white),
                        borderRadius: BorderRadius.circular(30)
                    ),
                    padding: EdgeInsets.all(20),
                    child: Text("START",
                      style: TextStyle(
                          fontSize: 60,
                          color: Colors.white.withOpacity(seleccion =="" ?0.3 : 1),
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              )
          )
         ],
      )
    );
  }
}
