

import 'package:flutter/material.dart';
import 'package:words/components/letters_widget.dart';
import 'package:words/components/result_widget.dart';

class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> {

  var _result = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Column(
        children: [
          Expanded(
              child: Container(
                alignment: Alignment.center,
                color: Colors.blue,
                child: ResultWidget(result: _result,),
              )
          ),
          Expanded(
              child: Container(
                color: Colors.red,
                child: LettersWidget(
                  onLetterPressed: (val){
                    print("HAN CLICADO LA $val");
                    _result += val;
                    setState(() {

                    });
                  },
                ),
              )
          ),
        ],
      )
    );
  }
}
