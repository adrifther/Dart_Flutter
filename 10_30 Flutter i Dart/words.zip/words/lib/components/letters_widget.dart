


import 'package:flutter/material.dart';

class LettersWidget extends StatefulWidget {

  Function onLetterPressed;

  LettersWidget({super.key,required this.onLetterPressed});

  @override
  State<LettersWidget> createState() => _LettersWidgetState();
}

class _LettersWidgetState extends State<LettersWidget> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        InkWell(
          onTap: (){
            print("PRESSED A");
            widget.onLetterPressed("A");
          },
          child: Container(
            width: 50,
            height: 50,
            child: Text("A",style: TextStyle(fontSize: 50),),
          ),
        ),
        InkWell(
          onTap: (){
            print("PRESSED B");
            widget.onLetterPressed("B");
          },
          child: Container(
            width: 50,
            height: 50,
            child: Text("B",style: TextStyle(fontSize: 50),),
          ),
        )
      ],
    );
  }
}
