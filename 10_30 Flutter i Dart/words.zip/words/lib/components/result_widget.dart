

import 'package:flutter/material.dart';

class ResultWidget extends StatefulWidget {
  String result;

  ResultWidget({super.key,required this.result});

  @override
  State<ResultWidget> createState() => _ResultWidgetState();
}

class _ResultWidgetState extends State<ResultWidget> {
  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.black,width: 2)
      ),
      width: 180,
      height: 50,
      child: Text("${widget.result}",textAlign: TextAlign.right,),

    );
  }
}
