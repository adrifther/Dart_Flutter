
import 'package:flutter/material.dart';

import '../select_gamer.dart';
import 'game_page.dart';

class LandingPage extends StatelessWidget {
  const LandingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              alignment: Alignment.center,
              child: InkWell(
                borderRadius: BorderRadius.circular(30),
                onTap: (){
                  //navegacion hacia GamePage()
                  Navigator.of(context).push(
                    MaterialPageRoute(builder: (context)=>SelectGamer())
                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                      border: Border.all(color:Colors.white),
                      borderRadius: BorderRadius.circular(30)
                  ),
                  padding: EdgeInsets.all(20),
                  child: Text("START",
                    style: TextStyle(
                        fontSize: 60,
                        color: Colors.white,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ),
            ),
          ),
          Expanded(
              child: Container(

                  alignment: Alignment.bottomLeft,
                  width: MediaQuery.of(context).size.width*0.75,
                  child: Image.asset('assets/logo.png'))),
        ],
      ),
    );
  }
}