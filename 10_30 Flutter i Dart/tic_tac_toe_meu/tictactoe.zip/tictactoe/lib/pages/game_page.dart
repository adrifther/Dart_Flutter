import 'dart:math';

import 'package:flutter/material.dart';

class GamePage extends StatefulWidget {

  String side;


  GamePage({super.key,required this.side});


  @override
  State<GamePage> createState() => _GamePageState();
}


class _GamePageState extends State<GamePage> {

  List<int> _board = List.generate(9, (index)=>0);

  int playerWin = 0;
  int cpuWin = 0;
  int draw = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(


      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Container(
                  decoration: BoxDecoration(color: Color(0xff48D2FE),
                  borderRadius: BorderRadius.all(Radius.circular(10.00)),
                  ),

                  width: 100,
                  height: 100,
                  child: Column(
                    children: [
                      Text("Player Pretzel",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight:FontWeight.bold),
                      ),
                      Text("${playerWin}", style: TextStyle(
                          fontSize: 28,
                          fontWeight:FontWeight.bold))
                    ],
                  )
                ),
                Container(
                    color: Color(0xffBBDBF9),
                    width: 100,
                    height: 100,
                    child: Column(
                      children: [
                        Text("Draw",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontSize: 20,
                                fontWeight:FontWeight.bold)
                        ),
                        Text("${draw}", style: TextStyle(
                            fontSize: 28,
                            fontWeight:FontWeight.bold)
                        )
                      ],
                    )
                ),
                Container(
                    color: Color(0xffE2BE00),
                    width: 100,
                    height: 100,
                    child: Column(
                      children: [
                        Text("CPU",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight:FontWeight.bold)
                        ),
                        Text("${cpuWin}", style: TextStyle(
                            fontSize: 28,
                            fontWeight:FontWeight.bold)
                        ),
                      ],
                    )
                )
              ],
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                GridView( // otra forma de hacer los 3 cuadrados de arriba.
                      shrinkWrap: true,
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount( // aquest delegate li dius cuantes lineas vols.
                                        crossAxisCount: 3,
                                        crossAxisSpacing: 10,
                                        mainAxisSpacing: 10,
                      ),
                      children: [
                        Container(
                          color: Color(0xff48D2FE),
                      ),
                        Container(

                      ),
                        Container(

                      )],
                ),
                GridView.builder( // puede tener children
                      shrinkWrap: true,      // hace que Gridview no se expanda infinito hacia abajo. porque lo tenemos dentro de un Center.
                        itemCount: _board.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount( // aquest delegate li dius cuantes lineas vols.
                          crossAxisCount: 3,
                          crossAxisSpacing: 10,
                          mainAxisSpacing: 10,
                        ),
                    itemBuilder: (context,index){
                  return InkWell(
                    onTap: (){
                      if(_board[index] == 0){
                        setState(() {
                          _board[index] = 1;
                        });
                        if (CheckWin(1)){
                          showAlert("You win!");
                          setState(() {
                            playerWin++;
                          });
                          return; //acaba la funcion, el break no acaba la funcion.
                        }
                      }
                      if(checkDraw()){
                        showAlert("Draw");
                        setState(() {
                          draw++;
                        });
                        return;
                      }
                      playCpu();
                      if(CheckWin(-1)){
                        showAlert("CPU WINS!");
                        setState(() {
                          cpuWin++;
                        });
                        return;
                      }

                      setState(() {

                      });
                    },
                    child: Container(
                      color: Color(0xff43115B),
                      height: 50,
                      width: 50,
                      alignment: Alignment.center,
                      child: _board[index] == 0 ?
                             SizedBox() : _board[index] == 1
                              ? Image.asset(widget.side=="D" ? "assets/donut.png" : "assets/pretzel.png")
                                : Image.asset(widget.side=="D" ? "assets/pretzel.png" : "assets/donut.png"),  //aqui funcionan ternarias
                    ),
                  );
                }),
              ],
            ),
          ],
        ),
      )
    );
  }

  bool CheckWin(player){
    if( (_board[0] == player && _board[1] == player && _board[2] == player) ||
        (_board[3] == player && _board[4] == player && _board[5] == player) ||
        (_board[6] == player && _board[7] == player && _board[8] == player) ||
        (_board[0] == player && _board[3] == player && _board[6] == player) ||
        (_board[1] == player && _board[4] == player && _board[7] == player) ||
        (_board[2] == player && _board[5] == player && _board[8] == player) ||
        (_board[0] == player && _board[4] == player && _board[8] == player) ||
        (_board[2] == player && _board[4] == player && _board[6] == player)){
      print("WIN & End of the game");
      return true;
    }else{
      print("play!");
      return false;}
  }

  void playCpu(){
    int A = Random().nextInt(9);
    while (_board[A] != 0){
      A = Random().nextInt(9);
    }

   setState(() {
     _board[A] = -1;
   });
  }

  bool checkDraw(){
    if(_board.contains(0)){
      return false;
    }else{
      return true;
    }
  }

  void showAlert(String message){
    showDialog(
        context: context,
        builder: (context){//widget para show Alert: alert Dialog
          return AlertDialog(
            content: Text(message),
            actions: [
              TextButton(
                  onPressed: (){
                    _board.fillRange(0, 8, 0);
                    setState(() {

                    });
                    Navigator.of(context).pop();
                  },
                  child: Text("OK"))
            ],
          );
        });
  }

}

