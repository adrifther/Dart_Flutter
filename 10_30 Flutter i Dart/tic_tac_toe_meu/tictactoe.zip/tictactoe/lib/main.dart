

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'pages/landing_page.dart';

void main(){
  runApp(const Myapp());
}

class Myapp extends StatelessWidget {
  const Myapp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(                             // configuracion del tema
        scaffoldBackgroundColor: Color(0xff5A1E76),   // 0xff es poca transparencia, sino se vería translúcida
      ),
      home: LandingPage(),
    );
  }
}
