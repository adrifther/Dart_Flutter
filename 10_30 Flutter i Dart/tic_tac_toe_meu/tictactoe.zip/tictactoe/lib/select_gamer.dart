import 'package:flutter/material.dart';

import 'pages/game_page.dart';

class SelectGamer extends StatefulWidget {  //al declarar variables, y para que el ontap haga algo hay que poner Statefull widget
  SelectGamer({super.key});
  @override
  State<SelectGamer> createState() => _SelectGamerState();
}

class _SelectGamerState extends State<SelectGamer> {
 //si posem variables treiem el const devant de SelectGamer
  var _seleccion = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff5A1E76),
      body: Column(
        children: [
          Expanded(
            flex: 1,
              child: Container( // siempre tiene que tener alineacion (Alignment) para que se expanda en horizontal y ocupe la pantalla.
                color: Colors.blue,
                alignment: Alignment.center,
                child: Text("Select your icon",
                  style: TextStyle(
                      fontSize: 40,
                  color: Colors.white),
                ),
              )
          ),
          Expanded(
            flex: 3,
              child: Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    InkWell(
                      onTap: (){
                        _seleccion = "D";
                        setState(() {});
                      },
                      child: Container(
                        color: _seleccion == "D" ? Colors.red : Colors.transparent, //ternaria, no puede ser if
                        width: MediaQuery.of(context).size.width/3,
                        child: Image.asset("assets/donut.png"),
                      ),
                    ),
                    InkWell(
                      onTap: (){
                        _seleccion == "P";
                        setState(() {});
                      },
                      child: Container(
                        color: _seleccion == "P" ? Colors.red : Colors.transparent,
                        width: MediaQuery.of(context).size.width/3,
                        child: Image.asset("assets/pretzel.png"),
                      ),
                    )
                  ],
                ),
              )
          ),
          Expanded(
            flex: 2,
              child: Container(
                color: Colors.white,
                child: InkWell(
                  onTap: (){
                    _seleccion != "" ? Navigator.of(context).push(
                      MaterialPageRoute(builder: (context) => GamePage(side: _seleccion))
                    ) : null;
                  },
                  child: Container(
                    alignment: Alignment.center,
                                decoration: BoxDecoration(
                                border: Border.all(color:Colors.blue),
                                borderRadius: BorderRadius.circular(30)
                            ),
                                padding: EdgeInsets.all(20),
                      child: Text("START",
                        style: TextStyle(
                            fontSize: 60,
                            color: Colors.black.withOpacity(_seleccion =="" ? 0.3 : 1),
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                ),
              )
          )
        ],
      ),
    );
  }
}
