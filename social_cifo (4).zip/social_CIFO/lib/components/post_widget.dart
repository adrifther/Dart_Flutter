


import 'package:flutter/material.dart';
import 'package:social_cifo/components/follow_button.dart';
import 'package:social_cifo/models/publication.dart';

import '../constants.dart';

class PostWidget extends StatelessWidget {

  Publication? publication;

  PostWidget({super.key,required this.publication});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.width + 250, //tamany de amplada
      margin: EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.black45,width: 2)
      ),
      child: Column(
        children: [
          ListTile(
            leading: ClipRRect( //per border radios a images
              borderRadius: BorderRadius.circular(50),//per border radios a images
              child: Container(
                  width: 50,
                  height: 50,
                  child: Image.network("$kImageBaseUrl/${publication?.user?.image ?? "default.png"}", fit: BoxFit.cover) // per arrodonir foto
              ),
            ),
            title: Text(publication?.user?.name ?? "N/A"),
            subtitle: Text("${publication?.createdAt}"),
            trailing: FollowButton(),
          ),

          Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                      width: MediaQuery.of(context).size.width, // saca el tamaño del ancho del context
                      height: MediaQuery.of(context).size.width,
                      child: Image.network("$kImageBaseUrl/${publication?.file ?? "default.png"}", fit: BoxFit.cover) //cubre toda la width
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  height: 80,
                  child: Text(publication?.text ?? "vr defecto si no hay texto en publicationvalor po"
                      "r defecto si no hay texto en publicationvat"
                      "o si no hay texto en publicationvato si no hay"
                      " texto en publicationvato si no hay texto en publicat"
                      "ionvato si no hay texto en publicationvato si no hay texto en public"
                      "ationvato si no hay texto en publicationvalor por defecto si no ha"
                      "y texto en publicationvalor por defecto si no hay texto er defecto si "
                      "no hay texto en publicationvalor por defecto si no hay texto en pu"
                      "blicationvalor por defecto si no hay texto en publication",
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.share, color: Colors.black),
                        Text("36")
                      ],
                    ),
                    Row(
                      children: [
                        Row(
                          children: [
                            Icon(Icons.heart_broken_outlined, color: Colors.black),
                            Text("36")
                          ],
                        ),
                        SizedBox(width: 20),
                        Row(
                          children: [
                            Icon(Icons.comment, color: Colors.black),
                            Text("36")
                          ],
                        ),
                      ],
                    ),
                  ],
                )
              ],
            ),
          ) //para mostrar tres puntos cuando hay mucho texto
        ],
      ),
    );
  }
}

