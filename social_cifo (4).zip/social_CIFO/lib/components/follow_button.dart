
import 'package:flutter/material.dart';

import '../constants.dart';

class FollowButton extends StatelessWidget {
  const FollowButton({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      width: 100,
      decoration: BoxDecoration(
        color: kPrimaryColor,
        borderRadius: BorderRadius.circular(50),

      ),
      alignment: Alignment.center,
      child: Text("Follow",style: TextStyle(fontSize: 14,color: Colors.white),),
    );
  }
}
