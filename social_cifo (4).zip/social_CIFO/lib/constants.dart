
import 'package:flutter/material.dart';

//THEME CONSTANTS
const kPrimaryColor = Color(0xEF3BD360);

// API CONSTANTS
const kBaseUrl = "https://cifo.indalter.es/api";


const kImageBaseUrl = '$kBaseUrl/publication/media';