


class FormHelpers{

  static bool isEmpty(String? value){

    if(value == null || value.isEmpty){
      return true;
    }else{
      return false;
    }
  }

  static bool isValidEmail(String? email) {
    String pattern =
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    RegExp regex = RegExp(pattern);
    return regex.hasMatch(email ?? "");
  }

  /*
 Al menos 8 caracteres.
// Al menos una letra mayúscula.
// Al menos una letra minúscula.
// Al menos un número.
// Al menos un carácter especial (por ejemplo, @, #, $, %, etc.).

// (?=.*[a-z]) asegura al menos una letra minúscula.
// (?=.*[A-Z]) asegura al menos una letra mayúscula.
// (?=.*\d) asegura al menos un dígito.
// (?=.*[@$!%*?&]) asegura al menos un carácter especial (puedes agregar o eliminar caracteres especiales en esta sección).
// [A-Za-z\d@$!%*?&]{8,} asegura que la longitud mínima sea de 8 caracteres y solo permite letras, dígitos y caracteres especiales especificados.
   */
  static bool isValidPass(String? password){
    String pattern = r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$';
    RegExp regex = RegExp(pattern);
    return regex.hasMatch(password ?? "");
  }


}