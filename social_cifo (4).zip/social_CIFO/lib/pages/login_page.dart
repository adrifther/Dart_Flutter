
import 'package:flutter/material.dart';
import 'package:social_cifo/components/custom_enter_button.dart';
import 'package:social_cifo/constants.dart';
import 'package:social_cifo/helpers/form_helpers.dart';
import 'package:social_cifo/pages/register_page.dart';
import 'package:social_cifo/pages/user_list_page.dart';
import 'package:social_cifo/repositories/user_repository.dart';

import '../components/back_botton_widget.dart';

class LoginPage extends StatefulWidget {
  LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {

  // CONTROLLERS PARA VALIDAR TEXTSFORMFIELDS

  var _controllerUser = TextEditingController(text: "cifotest@test.com");
  var _controllerPassword = TextEditingController(text: "123456");

  //ESTA KEY NOS SIRVE PARA LLAMAR A LOS VALIDADORES DEL FORMULARIO

  var _key = GlobalKey<FormState>();

  var _showPassword = false;




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 110,
        leadingWidth: 110,
        leading: Padding(
          padding: const EdgeInsets.all(25.0),
          child: BackBottonWidget(),
        )
      ),
      body: Padding(
        padding: const EdgeInsets.all(25.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Text("Hello Again!", style: Theme.of(context).textTheme.headlineLarge),
              Text("Sign to your account!", style: Theme.of(context).textTheme.titleSmall),
              SizedBox(height: 60),
              Form(
                key: _key,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextFormField(
                      decoration: InputDecoration(
                        hintText: "Enter your email...",
                        label: Text("Email Adress")
                      ),
                      controller: _controllerUser,
                      validator: (value){
                        if(value == null || value.isEmpty){
                          return "EL EMAIL NO PUEDE ESTAR VACIO";
                        }
                        if(!FormHelpers.isValidEmail(value)){
                          return "No es un email valido";
                        }
          
                        return null;
                      },
                    ),
                    SizedBox(height: 40),
                    TextFormField(
                      obscureText: !_showPassword,
                      decoration: InputDecoration(
                        hintText: "Enter your password...",
                          label: Text("Password"),
                        suffixIcon: IconButton(onPressed: (){
          
                          setState(() {
                            _showPassword = !_showPassword;
                          });
                        }, icon: Icon(_showPassword ? Icons.remove_red_eye_outlined: Icons.remove_red_eye),)
                      ),
                      controller: _controllerPassword,
                      validator: (value){
                        if(value == null || value.isEmpty){
                          return "EL PASSWORD NO PUEDE ESTAR VACIO";
                        }
                        return null;
                      },
          
          
                    ),
                    Container(
                      width: double.infinity,
                      alignment: Alignment.centerLeft,
                      child: TextButton(onPressed: (){
          
                        showModalBottomSheet(
                            context: context,
                            builder: (context){
                              return Container(
                                  width: double.infinity,
                                  height: 600,
                                  child: Text("HELLO"));
                            });

                      },
                          child: Text("Forgot password", style: TextStyle(
                            color: kPrimaryColor,
                            decoration: TextDecoration.underline,
                            decorationColor: kPrimaryColor,
                            decorationThickness: 1
                          ),)),
                    ),
                    SizedBox(height: 40),
                    // ElevatedButton(onPressed: (){
                    //
                    //   //ESTO DEVUELVE TRUE OR FALSE EN FUNCIÓN DE SI SE HA VALIDADO CORRECTAMENTE O NO
                    //
                    //   if(_key.currentState!.validate()){
                    //     // AQUI HARIAMOS LA LLAMADA DE LOGIN
                    //   }
                    // },
                    //   child: Text("BOTON")
                    // )
          
                    CustomEnterButton(
                      onTap: () async {
                        if (_key.currentState!.validate()) {
                          // AQUI HARIAMOS LA LLAMADA DE LOGIN
                          try {
                            await UserRepository().login(
                                _controllerUser.text, _controllerPassword.text);

                            Navigator.of(context).pushReplacement(
                                MaterialPageRoute(
                                    builder: (context) => UserListPage())
                            );
                          } catch (e) {
                            //Para mostrar un snackbar

                            ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                    content:Text("Ha habido un error en el login")
                                )
                            );
                          }
                        }
                      },
                    ),
                    SizedBox(height:20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Don't have an account?", style: Theme.of(context).textTheme.titleSmall),
                        TextButton(
                            onPressed: (){
                                  Navigator.of(context).push(
                                    MaterialPageRoute(builder: (context)=>RegisterPage())
                                  );
                            },
                            child: Text("Sign up", style: TextStyle(
                                color: kPrimaryColor,
                                decoration: TextDecoration.underline,
                                decorationColor: kPrimaryColor,
                                decorationThickness: 1
                            ),)
                        ),
                      ],
                    ),

                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

}



