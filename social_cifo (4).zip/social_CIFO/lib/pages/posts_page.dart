

import 'package:flutter/material.dart';
import 'package:social_cifo/components/post_widget.dart';
import 'package:social_cifo/models/publication.dart';
import 'package:social_cifo/models/publications_data.dart';
import 'package:social_cifo/repositories/posts_repository.dart';

// PostPage(userId:3432423432)

class PostsPage extends StatefulWidget {

  String userId;

  PostsPage({super.key,required this.userId});

  @override
  State<PostsPage> createState() => _PostsPageState();
}

class _PostsPageState extends State<PostsPage> {

  PublicationsData? _data;
  bool _loadingError = false;

  @override
  void initState(){
    super.initState();

    _loadData();
  }

  Future<void> _loadData() async {
    try {
      _data = await PostsRepository().getUsersPosts(userId: widget.userId);
    }catch(e){
      print("EXCEPTION $e");
      _loadingError = true;
    }

    setState(() {

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: !_loadingError ? ListView.builder(
                itemCount: _data?.publications?.length ?? 0, //
                itemBuilder: (context,index){   //farem tants widgets com item counts tinguem.
                  return PostWidget(publication: _data?.publications?[index]);
                },
              ) : Center(child: Text("There was an error loading posts"))
            )
          ],
        ),
      )
    );
  }
}

