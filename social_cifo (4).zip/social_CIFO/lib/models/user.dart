

class User{
  String id;
  String? name;
  String? nick;
  String? email;
  String? image;
  DateTime? createdAt;

  User({required this.id, this.name,this.nick,this.email,this.image,this.createdAt});

  factory User.fromJson(Map<String,dynamic> json) {
    return User(
      id: json["_id"],
      name:  json["name"],
      nick: json["nick"],
      email: json["email"],
      image: json["image"],
      createdAt: DateTime.tryParse(json["created_at"])
    );
  }
}

