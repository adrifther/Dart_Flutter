

import 'package:social_cifo/models/user.dart';

class Publication{

  String id;
  String? text;
  DateTime? createdAt;
  String? file;
  User? user;

  Publication({required this.id, this.text, this.createdAt, this.file, this.user});

  factory Publication.fromJson(Map<String,dynamic> json){

    return Publication(
      id: json["_id"],
      text: json["text"],
      file: json["file"],
      createdAt: DateTime.tryParse(json["created_at"]),
      user: User.fromJson(json["user"]),
    );


  }


}